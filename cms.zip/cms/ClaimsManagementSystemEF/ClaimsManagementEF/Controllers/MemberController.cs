﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ClaimsManagementEF.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ClaimsManagementEF.Controllers
{
    [EnableCors("ClaimsPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize(Roles = "Member")]
    public class MemberController : ControllerBase
    {
        ClaimsManagementContext claimsmanagement = new ClaimsManagementContext();
        [Route("GetByMemberId/{memberId}")]
        [HttpGet("{memberId}")]
        public IActionResult GetByMemberId(long memberId)
        {
            var claim = claimsmanagement.Tblclaim.Where(user => user.ClaimMemberid == memberId);
            if (claim != null)
            {
                return Ok(new { message = "Claimed", claims = claimsmanagement.Tblclaim.Where(user => user.ClaimMemberid == memberId) });
            }
            else
            {
                return Ok(new { message = "You haven't claimed anything yet!!!" });
            }
        }
        [Route("GetByEmailId/{emailId}")]
        [HttpGet("{emailId}")]
        public IActionResult GetByEmailId(string emailId)
        {
            Tblmember member = claimsmanagement.Tblmember.Where(mem => mem.MemberEmailid == emailId).FirstOrDefault();
            return Ok(member);
        }
        [HttpGet]
        public IActionResult Get()
        {

            return Ok(claimsmanagement.Tblmember);
        }
        [Route("MemberRegister")]
        [HttpPost]
        public IActionResult MemberRegister([FromBody] Tblmember claimmember)
        {
            Tblmember member = new Tblmember();
            member.MemberId = claimmember.MemberId;
            member.MemberFirstname = claimmember.MemberFirstname;
            member.MemberLastname = claimmember.MemberLastname;
            member.MemberAge = claimmember.MemberAge;
            member.MemberGender = claimmember.MemberGender;
            member.MemberDob = claimmember.MemberDob;
            member.MemberContactnumber = claimmember.MemberContactnumber;
            member.MemberAltcontactnumber = claimmember.MemberAltcontactnumber;
            member.MemberEmailid = claimmember.MemberEmailid;
            member.MemberPassword = claimmember.MemberPassword;
            member.MemberPlancode = claimmember.MemberPlancode;
            member.MemberCoveragestartdate = claimmember.MemberCoveragestartdate;
            member.MemberCoverageenddate = claimmember.MemberCoverageenddate;
            member.MemberAddressline1 = claimmember.MemberAddressline1;
            member.MemberAddressline2 = claimmember.MemberAddressline2;
            member.MemberCity = claimmember.MemberCity;
            member.MemberState = claimmember.MemberState;
            member.MemberZipcode = claimmember.MemberZipcode;
            member.MemberStatus = false;
            member.MemberRejectedstatuis = false;
            claimsmanagement.Tblmember.Add(member);
            claimsmanagement.SaveChanges();
            return Ok(new { message = "Member Registered" });
        }
        [Route("GetByClaimId/{claimid}")]
        [HttpGet("{claimid}")]
        public IActionResult GetByClaimId(long claimid)
        {
            var claim = claimsmanagement.Tblclaim.Where(p => p.ClaimId == claimid).FirstOrDefault();
            return Ok(claim);
        }

        [Route("GetPlanCode")]
        [HttpGet]
        public IActionResult GetPlanCode()
        {
            List<Tblplancode> plancodelist = new List<Tblplancode>();
            foreach (var item in claimsmanagement.Tblplancode)
            {
                plancodelist.Add(item);
            }
            return Ok(plancodelist);
        }
        [Route("ClaimDetails")]
        [HttpPost]
        public IActionResult ClaimDetails([FromBody] Tblclaim claimdet)
        {

            Tblclaim claim = new Tblclaim();
            claim.ClaimId = claimdet.ClaimId;
            claim.ClaimMemberid = claimdet.ClaimMemberid;
            claim.CliamSubmissiondate = DateTime.Now;
            claim.ClaimProcessingdate = DateTime.Now;
            claim.ClaimServicedate = DateTime.Now;
            claim.ClaimStatus = "pending";
            claim.ClaimAmount = claimdet.ClaimAmount;
            claim.MemberProofname1 = claimdet.MemberProofname1;
            claim.MemberProofId1 = claimdet.MemberProofId1;
            claim.MemberProofname2 = claimdet.MemberProofname2;
            claim.MemberProofId2 = claimdet.MemberProofId2;
            claim.MemberBills = claimdet.MemberBills;
            claimsmanagement.Tblclaim.Add(claim);
            claimsmanagement.SaveChanges();
            return Ok(new { message = "Claim Registered Suceessfully", claimId = claim.ClaimId });

        }

        [Route("ClaimDetailsEdit/{id}")]
        [HttpPut("{id}")]
        public IActionResult ClaimDetailsEdit([FromBody] Tblclaim claimdet, long id)
        {


            var claim = claimsmanagement.Tblclaim.Where(p => p.ClaimId == id).FirstOrDefault();
            claim.ClaimMemberid = claimdet.ClaimMemberid;
            claim.CliamSubmissiondate = DateTime.Now;
            claim.ClaimProcessingdate = DateTime.Now;
            claim.ClaimServicedate = DateTime.Now;
            claim.ClaimStatus = "pending";
            claim.ClaimAmount = claimdet.ClaimAmount;
            claim.MemberProofname1 = claimdet.MemberProofname1;
            claim.MemberProofId1 = claimdet.MemberProofId1;
            claim.MemberProofname2 = claimdet.MemberProofname2;
            claim.MemberProofId2 = claimdet.MemberProofId2;
            claim.MemberBills = claimdet.MemberBills;
            claimsmanagement.Tblclaim.Update(claim);
            claimsmanagement.SaveChanges();
            return Ok(new { message = "Claim Registered Suceessfully" });

        }

        [Route("ResubmitClaim/{id}")]
        [HttpGet("{id}")]
        public IActionResult ResubmitClaim(long id)
        {
            Tblclaim claimdet = new Tblclaim();
            var claim = from c in claimsmanagement.Tblclaim.Where(cl => cl.ClaimMemberid == id)
                        select new
                        {
                            c.ClaimId,
                            c.ClaimMemberid,
                            c.ClaimMember.MemberEmailid,
                            c.ClaimMember.MemberFirstname,
                            c.ClaimMember.MemberLastname,
                            c.ClaimMember.MemberContactnumber,
                            c.ClaimAmount,
                            c.MemberProofname1,
                            c.MemberProofname2,
                            c.MemberProofId1,
                            c.MemberProofId2,
                            c.MemberBills
                        };
            return Ok(claim);
        }


        [Route("ResubmitEditClaim/{id}")]
        [HttpGet("{id}")]
        public IActionResult ResubmitEditClaim(long id)
        {
            Tblclaim claimdet = new Tblclaim();
            var claim = from c in claimsmanagement.Tblclaim.Where(cl => cl.ClaimId == id)
                        select new
                        {
                            c.ClaimId,
                            c.ClaimMemberid,
                            c.ClaimMember.MemberEmailid,
                            c.ClaimMember.MemberFirstname,
                            c.ClaimMember.MemberLastname,
                            c.ClaimMember.MemberContactnumber,
                            c.ClaimAmount,
                            c.MemberProofname1,
                            c.MemberProofname2,
                            c.MemberProofId1,
                            c.MemberProofId2,
                            c.MemberBills
                        };
            return Ok(claim);
        }

        [Route("GiveFeedback")]
        [HttpPost]
        public IActionResult GiveFeedback([FromBody] Tbluserfeedback fduser)
        {
            Tbluserfeedback user = new Tbluserfeedback();
            user.UserfdId = fduser.UserfdId;
            user.UserfdRatingque1 = fduser.UserfdRatingque1;
            user.UserfdRatingque2 = fduser.UserfdRatingque2;
            user.UserfdRatingque3 = fduser.UserfdRatingque3;
            user.UserfdRatingque4 = fduser.UserfdRatingque4;
            user.UserfdRatingque5 = fduser.UserfdRatingque5;
            user.UserfdRatingque6 = fduser.UserfdRatingque6;
            user.UserfdRatingque7 = fduser.UserfdRatingque7;
            user.UserfdRatingque8 = fduser.UserfdRatingque8;
            user.UserfdRatingque9 = fduser.UserfdRatingque9;
            user.UserfdRatingque10 = fduser.UserfdRatingque10;
            user.UserfdAssessmentdate = DateTime.Now;
            claimsmanagement.Tbluserfeedback.Add(user);
            claimsmanagement.SaveChanges();
            return Ok(new { message = " Feedback is Given" });


        }

    }
}