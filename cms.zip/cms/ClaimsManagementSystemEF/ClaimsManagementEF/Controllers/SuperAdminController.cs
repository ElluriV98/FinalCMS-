﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ClaimsManagementEF.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ClaimsManagementEF.Controllers
{
    [EnableCors("ClaimsPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class SuperAdminController : ControllerBase
    {
        ClaimsManagementContext claimsmanagement = new ClaimsManagementContext();
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(claimsmanagement.Tbladmin);
        }
        [Route("AdminApproval/{adminId}/{status}")]
        [HttpPut("{adminId}/{status}")]

        public IActionResult AdminApproval(long adminId, bool status)
        {
            Tbladmin admin = claimsmanagement.Tbladmin.Where(usr => usr.AdminId == adminId).FirstOrDefault();
            if (status == true)
            {
                admin.AdminStatus = status;
                claimsmanagement.SaveChanges();
                return Ok(new { message = "Approved" });
            }
            else
            {
                return Ok(new { message = "Rejected" });
            }
        }
        [Route("GetByAdminStatus")]
        [HttpGet]
        public IActionResult GetByAdminStatus()
        {

            return Ok(claimsmanagement.Tbladmin.Where(user => user.AdminStatus == false && user.AdminRejectedstatuis == false));
        }

        [Route("GetAdminById/{adminId}")]
        [HttpGet("{adminId}")]
        public IActionResult GetAdminById(long adminId)
        {
            return Ok(claimsmanagement.Tbladmin.Where(ad => ad.AdminId == adminId).FirstOrDefault());
        }
        [Route("AdminRejection/{adminId}/{status}/{message}")]
        [HttpPut("{adminId}/{status}/{message}")]
        public IActionResult AdminRejection(long adminId, bool status, string message)
        {
            Tbladmin user = claimsmanagement.Tbladmin.Where(ad => ad.AdminId == adminId).FirstOrDefault();
            if (status == false)
            {
                user.AdminRejectedstatuis = true;
                user.AdminRejMessage = message;
                claimsmanagement.SaveChanges();
                return Ok(new { message = "Rejected By Super Admin" });
            }
            return Ok(new { message = "Not Approved/Rejected By Super Admin" });

        }
        [Route("MemberDetails")]
        [HttpGet]
        public IActionResult MemberDetails()
        {
            return Ok(claimsmanagement.Tblmember);
        }
        [Route("ClaimDetails")]
        [HttpGet]
        public IActionResult ClaimDetails()
        {
            return Ok(claimsmanagement.Tblclaim);
        }
    }

}

