﻿using System;
using System.Collections.Generic;

namespace ClaimsManagementEF.Models
{
    public partial class Tbluserfeedback
    {
        public long UserfdId { get; set; }
        public string UserfdRatingque1 { get; set; }
        public string UserfdRatingque2 { get; set; }
        public string UserfdRatingque3 { get; set; }
        public string UserfdRatingque4 { get; set; }
        public string UserfdRatingque5 { get; set; }
        public string UserfdRatingque6 { get; set; }
        public string UserfdRatingque7 { get; set; }
        public string UserfdRatingque8 { get; set; }
        public string UserfdRatingque9 { get; set; }
        public string UserfdRatingque10 { get; set; }
        public DateTime UserfdAssessmentdate { get; set; }
    }
}
