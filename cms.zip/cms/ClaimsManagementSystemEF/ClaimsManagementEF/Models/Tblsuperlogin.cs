﻿using System;
using System.Collections.Generic;

namespace ClaimsManagementEF.Models
{
    public partial class Tblsuperlogin
    {
        public long SuplgSuperid { get; set; }
        public string SuplgUsername { get; set; }
        public string SuplgPassword { get; set; }
    }
}
