﻿using System;
using System.Collections.Generic;

namespace ClaimsManagementEF.Models
{
    public partial class Tbladmin
    {
        public long AdminId { get; set; }
        public string AdminFirstname { get; set; }
        public string AdminLastname { get; set; }
        public int AdminAge { get; set; }
        public string AdminGender { get; set; }
        public DateTime AdminDateofbirth { get; set; }
        public long AdminContactnumber { get; set; }
        public long? AdminAltcontactnumber { get; set; }
        public string AdminEmailId { get; set; }
        public bool? AdminStatus { get; set; }
        public bool? AdminRejectedstatuis { get; set; }
        public string AdminRejMessage { get; set; }
    }
}
