import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { PlanCode } from 'src/app/registration/member/plancode';
import { Router } from '@angular/router';
import { DeprecatedDatePipe, DatePipe } from '@angular/common';
import { PasswordValidator } from 'src/app/shared/password.validators';

@Component({
  selector: 'app-signup-member',
  templateUrl: './signup-member.component.html',
  styleUrls: ['./signup-member.component.css']
})
export class SignupMemberComponent implements OnInit {
  baseUrl = "https://localhost:44367/api";
  Registrationform:FormGroup;
  data:Object;
  errorMessage:any;
  planCodes: PlanCode;
  Myage:number
  constructor( private datePipe:DatePipe, private fb:FormBuilder,private http:HttpClient, private router:Router) { }
  
  
  ngOnInit() {
    this.planCode().subscribe(
      data => {
        this.planCodes = JSON.parse(JSON.stringify(data))
        console.log(this.planCodes)
      }
    )
    this.Registrationform=this.fb.group({
      // memberId:['',[Validators.required,Validators.maxLength(10)]],
      memberFirstname:['',[Validators.required,Validators.pattern('^[A-Za-z]+$'),Validators.maxLength(50)]],
      memberLastname:['',[Validators.required,Validators.pattern('^[A-Za-z]+$'),Validators.maxLength(50)]],
      memberAge:['',[Validators.required, Validators.maxLength(2), Validators.pattern('^[0-9]+$')]],
      memberGender:['',[Validators.required]],
      memberDob:['',[Validators.required]],
      memberContactnumber:['',[Validators.required,Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      memberAltcontactnumber:['',[Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      memberEmailid:['',[Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+')]],
      memberPassword:['',[Validators.required,Validators.minLength(8),Validators.pattern('^[A-Za-z%]+[\\$#\\+{}:\\?\\.,~@\\"0-9%]+$')]],
      memberPlancode:['',[Validators.required]],
      memberCoveragestartdate:['',[Validators.required]],          
      memberCoverageenddate:['',[Validators.required]],
      memberAddressline1:['',[Validators.required]],
      memberAddressline2:['',[Validators.required]],   
      memberCity:['',[Validators.required,Validators.pattern('^[A-Za-z ]+$')]], 
      memberState:['',[Validators.required,Validators.pattern('^[A-Za-z ]+$')]],
      memberZipcode:['',[Validators.required,Validators.minLength(6), Validators.maxLength(6), Validators.pattern('^[0-9]+$')]]    
    
 },{validator:PasswordValidator});
 
  }
  getAge(dateOfBirth:Date):number{
    //  var today = Date.now;
    //  var age = today.
    console.log(dateOfBirth);
    console.log("age");
      let today = new Date();
      let todayDate  = this.datePipe.transform(today, 'yyyy')
      var birthdate = new Date(dateOfBirth);
      let birthDay = this.datePipe.transform(birthdate,'yyyy')
      this.Myage = Number(todayDate) - Number(birthDay)
      let m = today.getMonth()-birthdate.getMonth();
      if(m<0 || (m==0 && today.getDate()< birthdate.getDate())){
        this.Myage--;
        }
        console.log(this.Myage);
        this.Registrationform.patchValue({memberAge : this.Myage})
        return this.Myage;
  }
  
  
  planCode()
  {
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.get(this.baseUrl+"/member/GetPlanCode",options)
  }

  
  onSignup(){
    console.log("In Submit")
     console.log(this.Registrationform.value);
    let respone=this.addUser(this.Registrationform)
    respone.subscribe(
      data=>{
        console.log(data['message'])
        this.router.navigateByUrl("registrationNotification")
      },
      error => console.log(error)
    );
    
  }
  addUser(user:any)
  {
    let body=user.value
    let header=new HttpHeaders({'content-type':'application/json','responseType':'text'});
    let options={headers:header};
    return this.http.post("https://localhost:44367/api/member/memberRegister",body,options);
  }
}
