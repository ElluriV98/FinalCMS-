import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-signup-admin',
  templateUrl: './signup-admin.component.html',
  styleUrls: ['./signup-admin.component.css']
})
export class SignupAdminComponent implements OnInit {
  AdminForm:FormGroup;
  data: Object;
  errorMessage: any;
  Myage:number;
  baseUrl = "https://localhost:44367/api";
  constructor( private datePipe:DatePipe, private fb:FormBuilder,private http:HttpClient,private router:Router) { }

  ngOnInit() {
    this.AdminForm = this.fb.group({
      // adminId:[''],
      adminFirstname:['',[Validators.required,Validators.pattern('^[A-Za-z]+$'),Validators.maxLength(50)]],
      adminLastname:['',[Validators.required,Validators.pattern('^[A-Za-z]+$'),Validators.maxLength(50)]],
      adminAge:['',[Validators.required, Validators.maxLength(2), Validators.pattern('^[0-9]+$')]],
      adminGender:['',Validators.required],
      adminDateofbirth:['',Validators.required],
      adminContactnumber:['',[Validators.required,Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      adminAltcontactnumber:['',[Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      adminEmailId:['',[Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+')]],
    });
  }

  getAge(dateOfBirth:Date):number{
    //  var today = Date.now;
    //  var age = today.
    console.log(dateOfBirth);
    console.log("age");
      let today = new Date();
      let todayDate  = this.datePipe.transform(today, 'yyyy')
      var birthdate = new Date(dateOfBirth);
      let birthDay = this.datePipe.transform(birthdate,'yyyy')
      this.Myage = Number(todayDate) - Number(birthDay)
      let m = today.getMonth()-birthdate.getMonth();
      if(m<0 || (m==0 && today.getDate()< birthdate.getDate())){
        this.Myage--;
        }
        console.log(this.Myage);
        this.AdminForm.patchValue({adminAge : this.Myage})
        return this.Myage;
  }
  
  get formControls() { return this.AdminForm.controls; }
  onSubmit()
  {
    let response = this.addUser(this.AdminForm)
    response.subscribe(
      data=> {
            console.log(data['message'])
            this.router.navigateByUrl("registrationNotification")
           
      },
      error => this.errorMessage = <any>error
    );
    console.log(this.errorMessage)
  }
  planCode()
  {
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' })
    let options = { headers: header };
    return this.http.get(this.baseUrl+"/member/GetPlanCode",options)
  }

  addUser(user:any)
  {
    let body = JSON.stringify(user.value)
    let header = new HttpHeaders({ 'Content-Type': 'application/json', 'responseType': 'text' });
    let options = { headers: header };
    return this.http.post("https://localhost:44367/api/admin/AdminRegister",body,options);
  }
}
