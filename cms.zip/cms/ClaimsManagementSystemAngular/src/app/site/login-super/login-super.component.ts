import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/registration/user.service';

@Component({
  selector: 'app-login-super',
  templateUrl: './login-super.component.html',
  styleUrls: ['./login-super.component.css']
})
export class LoginSuperComponent implements OnInit {
  Loginform: FormGroup;
  msg:String=null;
  submitted = false;
  showModal: boolean;
  constructor(private fb: FormBuilder, private router: Router, private userService: UserService) { }

  ngOnInit() {
    this.Loginform=this.fb.group({
      suplgUsrname:['',Validators.required],
      suplgPassword:['',Validators.required]
    });
  }


  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.Loginform.invalid) {
        return;
    }
    if(this.submitted)
    {

      console.log(this.Loginform.value);
      this.userService.admin = false;
      this.userService.member = false;
      this.userService.superUser = true;
      this.userService.authenticateSuperuser(this.Loginform).subscribe(

        data => {
          this.msg=data as String;
          console.log(this.msg)
          
         
          
          // console.log(this.userService.admin);
          // this.userService.user = data['user']
          console.log(data['message'])
          if(data['message']=="Logged In Successfully")
          {
            
            console.log("logged in succesfully");

            
            this.router.navigateByUrl('adminApproval');
          }
        },
        error => console.log(error)
      )
     
    }
  }
}

