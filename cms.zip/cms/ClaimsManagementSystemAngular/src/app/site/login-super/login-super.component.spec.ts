import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginSuperComponent } from './login-super.component';

describe('LoginSuperComponent', () => {
  let component: LoginSuperComponent;
  let fixture: ComponentFixture<LoginSuperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginSuperComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginSuperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
