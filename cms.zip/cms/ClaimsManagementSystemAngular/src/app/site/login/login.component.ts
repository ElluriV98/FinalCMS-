import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/registration/user.service';
import { AuthGaurdService } from 'src/app/registration/auth-gaurd.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  showModal: boolean;
  message:any
  messageAdmin:any
  isAdmin: boolean = false;
  submitted = false;
  role = "admin";

  Loginform:FormGroup;
  constructor(private fb: FormBuilder, private router: Router, private userService: UserService,private authGaurd:AuthGaurdService)  { }
  

  ngOnInit() {
    this.Loginform=this.fb.group({
      adminEmailId:['',Validators.required],
      adminFirstname:['',Validators.required]
    });
   
  }
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.Loginform.invalid) {
        return;
    }
    if(this.submitted)
    {
      this.userService.authenticate(this.Loginform).subscribe(
        data => {
          console.log(data)
          //let status = JSON.parse(JSON.stringify(data))['status'];
         
            // console.log(data['user'])
            // console.log("approved");
            this.userService.admin = true
            this.userService.member = false
            this.userService.user = data['user']
            if(data['message']=="Logged In Successfully")
            {
              this.message=data['message'];
              this.router.navigateByUrl('memberApproval')
            }
            else if(data['message']=="User not approved"){
              this.userService.member = false
              this.userService.admin = false
              this.userService.superUser = false
              this.message=data['message'];
              console.log(this.message)
              this.messageAdmin =this.userService.user['adminRejMessage'];
              console.log(this.messageAdmin)
              this.userService.user=null;
            }
            else
            {
              this.userService.member = false
              this.userService.admin = false
              this.userService.superUser = false
              this.message=data['message'];
              this.messageAdmin = data['message'];
              this.userService.user = null;
            }
          
        },
        error => console.log(error)
      )
      this.showModal = false;
    }
   
}


}


