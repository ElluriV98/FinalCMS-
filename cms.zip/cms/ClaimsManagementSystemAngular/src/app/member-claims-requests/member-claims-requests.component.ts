import { Component, OnInit } from '@angular/core';
import { UserService } from '../registration/user.service';
import { Observable } from 'rxjs';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-member-claims-requests',
  templateUrl: './member-claims-requests.component.html',
  styleUrls: ['./member-claims-requests.component.css']
})
export class MemberClaimsRequestsComponent implements OnInit {
  approveClick:boolean=false;
  rejectClick:boolean = false;
  isClaimViewed:boolean=false;
  claimRequests:Observable<any[]>;
  approveForm:FormGroup;
  rejectForm:FormGroup;
  message:any
  memberDetails:any
  constructor(private userService:UserService,private fb:FormBuilder ) { }

  ngOnInit() {
    this.claimRequests = this.userService.requestClaimDetails()
    console.log(this.claimRequests);
    this.approveForm = this.fb.group({
      approve:['',Validators.required]
    })

    this.rejectForm = this.fb.group({
      reject:['',Validators.required]
    })
  }

  viewMemberDetailsByClaimId(claimid:any,memberid:any){
    console.log("success");
    this.isClaimViewed=true;
    console.log(this.isClaimViewed);
    this.userService.requestMemberDetailsByClaimId(claimid,memberid).subscribe(
      data=>{
        console.log(data)
        this.memberDetails=data[0];
        console.log(this.memberDetails);
        console.log(this.memberDetails['claimId']);
      }
    
    )
  }
  rejectNewClaim(){
   this.rejectClick= true;
   this.approveClick=false;
   console.log("Claim Rejected By Admin");
  }

  acceptNewClaim(){
  this.approveClick = true;
  this.rejectClick=false;
  console.log("Claim Approved By Admin");
  }

  onApproveClaim(id:number){
    console.log("on Approval");
    this.message = this.approveForm.get('approve').value;
    console.log(this.message);
  this.userService.onClaimApproval(id,"Approved",this.message).subscribe(
    data => {
      console.log(JSON.parse(JSON.stringify(data))['message'])
      this.claimRequests = this.userService.requestClaimDetails()
      this.isClaimViewed=false;
    }
   )
  }
  onRejectClaim(id:number){
    console.log("on Reject");
    this.message = this.rejectForm.get('reject').value;
    console.log(this.message);
  this.userService.onClaimReject(id,"Rejected",this.message).subscribe(
    data => {
      console.log(JSON.parse(JSON.stringify(data))['message'])
      this.claimRequests = this.userService.requestClaimDetails()
      this.isClaimViewed=false;
    }
   )
  }
}
