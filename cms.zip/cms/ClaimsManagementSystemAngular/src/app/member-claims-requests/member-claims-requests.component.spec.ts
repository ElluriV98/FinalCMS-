import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberClaimsRequestsComponent } from './member-claims-requests.component';

describe('MemberClaimsRequestsComponent', () => {
  let component: MemberClaimsRequestsComponent;
  let fixture: ComponentFixture<MemberClaimsRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MemberClaimsRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MemberClaimsRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
