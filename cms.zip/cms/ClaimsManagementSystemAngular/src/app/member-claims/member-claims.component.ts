import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-claims',
  templateUrl: './member-claims.component.html',
  styleUrls: ['./member-claims.component.css']
})
export class MemberClaimsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
