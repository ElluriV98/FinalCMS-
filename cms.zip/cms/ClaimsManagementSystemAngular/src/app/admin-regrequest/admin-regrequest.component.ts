import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { UserService } from '../registration/user.service';
import { stringify } from 'querystring';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-admin-regrequest',
  templateUrl: './admin-regrequest.component.html',
  styleUrls: ['./admin-regrequest.component.css']
})
export class AdminRegrequestComponent implements OnInit {
  message:any
  rejectClick:boolean=false;
  isAdminViewed:boolean= false;
  adminRegistrations:Observable<any[]>
  adminDetails:any
  commentForm:FormGroup
  registrations:any
  constructor(private router:Router,private userService:UserService,private fb:FormBuilder) { }

  ngOnInit() {
    this.adminRegistrations = this.userService.requestAdminDetails()
    console.log(this.adminRegistrations)
    this.commentForm = this.fb.group({
      reject:['',Validators.required]
    })
  }
  viewAdminDetails(id:number)
  {
    console.log("success");
    this.isAdminViewed=true;
    console.log(this.isAdminViewed);
    this.userService.viewAdminDetailsById(id).subscribe(
      data=>{
        console.log(data)
        this.adminDetails=data;
        console.log(this.adminDetails['adminId']);
      }
    )   
  }
  acceptNewadmin(id:number)                              
  {
    console.log("Accepted method activated");
    console.log(id);
    this.userService.acceptAdmin(id,true).subscribe(
      data => {
        console.log(JSON.parse(JSON.stringify(data))['message'])
        this.adminRegistrations = this.userService.requestAdminDetails()
        this.isAdminViewed = false;
       }
    )
  }
 

 onReject(id:number)
 {
  console.log("on Reject");
  this.message = this.commentForm.get('reject').value
  console.log(this.message);  
  this.userService.rejectAdmin(id,false,this.message).subscribe(
    data => {
     console.log(JSON.parse(JSON.stringify(data))['message'])
     this.adminRegistrations = this.userService.requestAdminDetails()
     this.isAdminViewed = false;
    }
  )
  
 }
}
