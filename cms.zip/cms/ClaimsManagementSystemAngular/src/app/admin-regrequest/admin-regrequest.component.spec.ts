import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminRegrequestComponent } from './admin-regrequest.component';

describe('AdminRegrequestComponent', () => {
  let component: AdminRegrequestComponent;
  let fixture: ComponentFixture<AdminRegrequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminRegrequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminRegrequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
