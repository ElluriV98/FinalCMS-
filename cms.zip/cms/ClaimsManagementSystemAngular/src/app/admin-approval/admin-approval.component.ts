import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { UserService } from '../registration/user.service';

@Component({
  selector: 'app-admin-approval',
  templateUrl: './admin-approval.component.html',
  styleUrls: ['./admin-approval.component.css']
})
export class AdminApprovalComponent implements OnInit {
  memberDetails:boolean=false;
  memberRegisteredDetails:Observable<any[]>
  memberClaimDetails:Observable<any[]>
  claimDetails:boolean=false;

  constructor(private router:Router,private userService:UserService) { }

  ngOnInit() {
  }
  onAdminregistrations(){
    this.router.navigateByUrl('adminRequest');
    }

    getMemberDetails()
{
  this.memberDetails=true;
  this.claimDetails=false;
  console.log("Get Member Details");
  this.memberRegisteredDetails = (this.userService.memberDetails())
    console.log(this.memberRegisteredDetails)
}
getClaimDetails()
{
  this.claimDetails=true;
  this.memberDetails=false;
  console.log("Get Claim Details");
  this.memberClaimDetails= this.userService.getAllClaimDetails()
   console.log(this.memberClaimDetails)
}
}
