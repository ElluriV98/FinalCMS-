import { Component, OnInit } from '@angular/core';
import { UserService } from '../registration/user.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  isMember:boolean=false
  isAdmin:boolean=false

 userDetails:any
  constructor(private userService:UserService) { }

  ngOnInit() {
    this.isMember=this.userService.member
    this.isAdmin=this.userService.admin
    this.userDetails= this.userService.user
  }

}
