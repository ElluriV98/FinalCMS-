import { AbstractControl } from "@angular/forms";

export function PasswordValidator(control:AbstractControl):{[key:string]:boolean}|null{
    
    const memberContactnumber =control.get('memberContactnumber');
    const memberAltcontactnumber=control.get('memberAltcontactnumber');
    if(memberContactnumber.pristine || memberAltcontactnumber.pristine){
        return null;

    }
    return memberContactnumber && memberAltcontactnumber && memberContactnumber.value==memberAltcontactnumber.value?{'Mismatch':true}:null;
}
