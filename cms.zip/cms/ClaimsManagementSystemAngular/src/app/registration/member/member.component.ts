import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators,FormGroup } from '@angular/forms';

@Component({
  selector: 'appMember',
  templateUrl: './member.component.html',
  styleUrls: ['./member.component.css']
})
export class MemberComponent implements OnInit {
  
  Registrationform:FormGroup;
  constructor(private fb:FormBuilder) { }
  



  
  ngOnInit() {
    this.Registrationform=this.fb.group({
      memberId:['',[Validators.required,Validators.maxLength(10)]],
      memberFirstname:['',[Validators.required,Validators.pattern('^[A-Za-z]+$'),Validators.maxLength(50)]],
      memberLastname:['',[Validators.required,Validators.pattern('^[A-Za-z]+$'),Validators.maxLength(50)]],
      memberAge:['',[Validators.required, Validators.maxLength(2), Validators.pattern('^[0-9]+$')]],
      memberGender:['',[Validators.required]],
      memberDob:['',[Validators.required]],
      memberContactnumber:['',[Validators.required,Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      memberAltcontactnumber:['',[Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      memberEmailid:['',[Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+')]],
      memberPassword:['',[Validators.required,Validators.minLength(8),Validators.pattern('^[A-Za-z%]+[\\$#\\+{}:\\?\\.,~@\"0-9]+$')]],
      memberPlancode:['',[Validators.required]],
      memberCoveragestartdate:['',[Validators.required]],          
      memberCoverageenddate:['',[Validators.required]],
      memberAddressline1:['',[Validators.required]],
      memberAddressline2:['',[Validators.required]],   
      memberCity:['',[Validators.required,Validators.pattern('^[A-Za-z ]+$')]], 
      memberState:['',[Validators.required,Validators.pattern('^[A-Za-z ]+$')]],
      memberZipcode:['',[Validators.required,Validators.minLength(6), Validators.maxLength(6), Validators.pattern('^[0-9]+$')]]
      
    
 });
 
  }

  get formControls() { return this.Registrationform.controls; }
  
  // get Memberid(){
  //   return this.Registrationform.get('memberid');
  // }
  // get Firstname(){
  //   return this.Registrationform.get('firstName');
  // }
  // get Lastname(){
  //   return this.Registrationform.get('lastName');
  // }
  // get Age(){
  //   return this.Registrationform.get('age');
  // }
  // get Gender(){
  //   return this.Registrationform.get('gender');
  // }
  // get DateOfBirth(){
  //   return this.Registrationform.get('dateOfBirth');
  // }
  // get ContactNumber(){
  //   return this.Registrationform.get('contactNumber');
  // }
  // get AltcontactNumber(){
  //   return this.Registrationform.get('altcontactNumber');
  // }
  // get EmailId(){
  //   return this.Registrationform.get('emailId');
  // }
  // get Password(){
  //   return this.Registrationform.get('password');
  // }
  // get Plancode(){
  //   return this.Registrationform.get('plancode');
  // }
  // get Coveragestart(){
  //   return this.Registrationform.get('coveragestart');
  // }
  // get Coverageend(){
  //   return this.Registrationform.get('coverageend');
  // }
  // get AddressLine1(){
  //   return this.Registrationform.get('addressLine1');
  // }
  // get AddressLine2(){
  //   return this.Registrationform.get('address2');
  // }
  // get City(){
  //   return this.Registrationform.get('city');
  // }
  // get State(){
  //   return this.Registrationform.get('state');
  // }
  // get Zipcode(){
  //   return this.Registrationform.get('zipcode');
  // }
  
  onSignup(){
    console.log("In Submit")
    console.log(this.Registrationform.value);
  }
}
