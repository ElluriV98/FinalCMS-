export interface Admin{
    adminId:number;
    adminFirstname:string;
    adminLastname:string;
    adminAge:number;
    adminGender:string;
    adminDateofbirth:Date;
    adminContactnumber:number;
    adminAltcontactnumber:number;
    adminEmailId:string;
    adminStatus:boolean;
    adminRejMessage:string;

}