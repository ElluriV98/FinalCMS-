import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { HttpClient } from 'selenium-webdriver/http';

@Injectable({
  providedIn: 'root'
})
export class MemberService {
  baseUrl=environment.baseUrl+'member';
  memberUrl=environment.baseUrl;
  adminApproval:boolean;
  constructor(private httpClient: HttpClient, private route: Router) { }
  

}
