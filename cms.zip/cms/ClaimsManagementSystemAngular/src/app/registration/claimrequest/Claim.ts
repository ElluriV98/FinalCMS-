export interface Claim{
     claimId: number
     claimMemberid: number
     claimServicedate: Date 
     cliamSubmissiondate: Date
     claimProcessingdate:Date 
     claimStatus: string
     claimAmount: number 
     claimApprovedamount: number 
     memberProofname1:string
     memberProofname2:string
     memberProofId1:string
     memberProofId2:string
     memberBills:string
}