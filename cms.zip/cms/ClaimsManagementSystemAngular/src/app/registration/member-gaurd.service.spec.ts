import { TestBed } from '@angular/core/testing';

import { MemberGaurdService } from './member-gaurd.service';

describe('MemberGaurdService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MemberGaurdService = TestBed.get(MemberGaurdService);
    expect(service).toBeTruthy();
  });
});
