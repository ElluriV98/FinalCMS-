import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';

import { AdminComponent } from './registration/admin/admin.component';
import { MemberComponent } from './registration/member/member.component';
import { ClaimrequestComponent } from './registration/claimrequest/claimrequest.component';

import { LoginComponent } from './site/login/login.component';
import { HeaderComponent } from './site/header/header.component';
import { FooterComponent } from './site/footer/footer.component';
import { HomeComponent } from './registration/home/home.component';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { SignupAdminComponent } from './site/signup-admin/signup-admin.component';
import { HttpClientModule } from '@angular/common/http';
import { SignupMemberComponent } from './site/signup-member/signup-member.component';
import { LoginMemberComponent } from './site/login-member/login-member.component';
import { MemberApprovalComponent } from './member-approval/member-approval.component';
import { AuthGaurdService } from './registration/auth-gaurd.service';
import { MemberClaimsComponent } from './member-claims/member-claims.component';
import { MemberGaurdService } from './registration/member-gaurd.service';
import { NotificationComponent } from './registration/notification/notification.component';
import { RegistrationRequestComponent } from './registration-request/registration-request.component';
import { AsyncPipe, DatePipe } from '@angular/common';
import { LoginSuperComponent } from './site/login-super/login-super.component';
import { AdminApprovalComponent } from './admin-approval/admin-approval.component';
import { AdminRegrequestComponent } from './admin-regrequest/admin-regrequest.component';
import { MemberClaimsRequestsComponent } from './member-claims-requests/member-claims-requests.component';
import { ClaimStatusComponent } from './claim-status/claim-status.component';
import { ResubmitClaimComponent } from './registration/resubmit-claim/resubmit-claim.component';
import { AboutComponent } from './site/about/about.component';
import { ContactComponent } from './site/contact/contact.component';
import { HomefooterComponent } from './site/homefooter/homefooter.component';
import { SubmitStatusComponent } from './submit-status/submit-status.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { ProfileComponent } from './profile/profile.component';



@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    MemberComponent,
    ClaimrequestComponent,
  
    LoginComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    SignupAdminComponent,
    SignupMemberComponent,
    LoginMemberComponent,
    MemberApprovalComponent,
    MemberClaimsComponent,
    NotificationComponent,
    RegistrationRequestComponent,
    LoginSuperComponent,
    AdminApprovalComponent,
    AdminRegrequestComponent,
    MemberClaimsRequestsComponent,
    ClaimStatusComponent,
    ResubmitClaimComponent,
    AboutComponent,
    ContactComponent,
    HomefooterComponent,
    SubmitStatusComponent,
    FeedbackComponent,
    ProfileComponent,

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    RouterModule.forRoot([
      {path:'header',component:HeaderComponent},
      {path:'footer',component:FooterComponent},
      {path:'home', component:HomeComponent},
      {path:'login',component:LoginComponent},
      {path:'memberApproval',component:MemberApprovalComponent, canActivate:[AuthGaurdService]},
      {path:'memberClaims/:memberId',component:MemberClaimsComponent, canActivate:[MemberGaurdService]},
      {path:'memberRequest',component:RegistrationRequestComponent},
      {path:'registrationNotification',component:NotificationComponent},
      {path:'claimRequest/:memberId',component:ClaimrequestComponent},
      {path:'loginMember',component:LoginMemberComponent},
      {path:'loginSuper',component:LoginSuperComponent},
      {path:'adminApproval',component:AdminApprovalComponent},
       {path:'signupAdmin',component:SignupAdminComponent},
       {path:'signupMember',component:SignupMemberComponent},
       {path:'claimStatus',component:ClaimStatusComponent},
       {path:'profile',component:ProfileComponent},
       {path:'adminRequest',component:AdminRegrequestComponent},
       {path:'resubmit/:claimId',component:ResubmitClaimComponent},
       {path:'submitstatus/:claimId',component:SubmitStatusComponent},
       {path:'memberClaimsRequest',component:MemberClaimsRequestsComponent},
      {path:'about',component:AboutComponent},
      {path:'feedback',component:FeedbackComponent},
       {path:'contact',component:ContactComponent},
      {path:'',redirectTo:'home',pathMatch:'full'}
    ])
  ],

  providers: [AsyncPipe,DatePipe],
  bootstrap: [AppComponent]
})

export class AppModule { }
