IF EXISTS (SELECT * FROM sys.databases WHERE name = N'ClaimsManagement')
BEGIN
       DROP DATABASE ClaimsManagement
       CREATE DATABASE ClaimsManagement
END
ELSE
BEGIN
       CREATE DATABASE ClaimsManagement
END
GO

USE ClaimsManagement
GO

/**Member Table **/


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[tblmember](
       [member_id] [bigint] IDENTITY(1,1) NOT NULL,
       [member_firstname] [varchar](50) NOT NULL,
       [member_lastname] [varchar](50) NOT NULL,
       [member_age] [integer] NOT NULL,
       [member_gender] [varchar](6) NOT NULL,
       [member_dob] [date] NOT NULL,
       [member_contactnumber] [bigint] NOT NULL,
	   [member_altcontactnumber] [bigint] NULL,
	   [member_emailid] [varchar](50) NOT NULL,
	   [member_password] [varchar](50) NOT NULL,
	   [member_plancode] [bigint] NOT NULL,
	   [member_coveragestartdate] [date] NOT NULL,
	   [member_coverageenddate] [date] NOT NULL,
	   [member_addressline1] [varchar](150) NOT NULL,
	   [member_addressline2] [varchar](150) NOT NULL,
	   [member_city] [varchar](50) NOT NULL,
	   [member_state] [varchar](50) NOT NULL,
	   [member_zipcode] [bigint] NOT NULL
CONSTRAINT [PK_tbl_member] PRIMARY KEY CLUSTERED 
(
       [member_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

insert into tblmember values('abhijith','abhi',22,'male','12/02/1997',1234098765,0129384756,'abhijith@gmail.com','abhi@123',1,'12/02/2017','01/02/2018','ajfhajaf','gsdfgiweu','dshghfsdf','ksjdfjf',123456,0)

/** Admin table **/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[tbladmin](
       [admin_id] [bigint] IDENTITY(1,1) NOT NULL,
       [admin_firstname] [varchar](50) NOT NULL,
       [admin_lastname] [varchar](50) NOT NULL,
       [admin_age] [integer] NOT NULL,
       [admin_gender] [varchar](6) NOT NULL,
       [admin_dateofbirth] [date] NOT NULL,
       [admin_contactnumber] [bigint] NOT NULL,
	   [admin_altcontactnumber] [bigint] NULL,
	   [admin_emailId] [varchar](50) NOT NULL
CONSTRAINT [PK_tbl_admin] PRIMARY KEY CLUSTERED 
(
       [admin_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

/** claim table **/


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[tblclaim](
       [claim_id] [bigint] IDENTITY(1,1) NOT NULL,
	   [claim_memberid] [bigint] NOT NULL,
       [claim_servicedate] [date] NULL,
       [cliam_submissiondate] [date] NULL,
       [claim_processingdate] [date] NULL,
       [claim_status] [varchar](3) NULL,
       [claim_amount] [bigint] NULL,
       [claim_approvedamount] [bigint] NULL
CONSTRAINT [PK_tbl_claim] PRIMARY KEY CLUSTERED 
(
       [claim_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO



/** plan code  table */

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[tblplancode](
       [plan_code] [bigint] IDENTITY(1,1) NOT NULL,
       [plan_description] [varchar](50) NULL,
       [plan_coverage1] [varchar](50) NULL,
       [plan_coverage2] [varchar](50) NULL,
       [plan_coverage3] [varchar](50) NULL,
       [plan_coverage4] [varchar](50) NULL,
       [plan_coverage5] [varchar](50) NULL
CONSTRAINT [PK_tbl_plan] PRIMARY KEY CLUSTERED 
(
       [plan_code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/** SuperUser Login Table **/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[tblsuperlogin](
[suplg_superid] [bigint] IDENTITY(1,1) NOT NULL,
[suplg_username] [varchar](50) NOT NULL,
[suplg_password] [varchar](15) NOT NULL
 CONSTRAINT [PK_tbl_fsuperlogin] PRIMARY KEY CLUSTERED 
(
       [suplg_superid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

insert into tblsuperlogin values('superadmin@cts.com','cts@id004')

select * from tblsuperlogin


/** Feedback table **/


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[tblfeedback](
       [feedback_assessmentid] [bigint] IDENTITY(1,1) NOT NULL,
	   [feedback_question1] [varchar](200) NOT NULL,
	   [feedback_question2] [varchar](200) NOT NULL,
       [feedback_question3] [varchar](200) NOT NULL,
	   [feedback_question4] [varchar](200) NOT NULL,
	   [feedback_question5] [varchar](200) NOT NULL,
	   [feedback_question6] [varchar](200) NOT NULL,
	   [feedback_question7] [varchar](200) NOT NULL,
	   [feedback_question8] [varchar](200) NOT NULL,
	   [feedback_question9] [varchar](200) NOT NULL,
	   [feedback_question10] [varchar](200) NOT NULL
CONSTRAINT [PK_tbl_feedback] PRIMARY KEY CLUSTERED 
(
       [feedback_assessmentid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO




insert into tblfeedback values('Did we meet your expectations?',
' How would you rate your interaction with our employees?',
' Was it easy to find what you were looking for?',
'How likely are you to repeat your business with us?',
'What would have made your experience with us better?',
'Were we able to satisfy your need?',
'How could we have exceeded your expectations?',
'What do you like most about Us?',
'-
',
' Is there anything else you would like us to know about your experience?'
)

insert into tbluserfeedback values('fhh','dfgfg','gffg','dgdg','fdggdf','dfgfg','e6yr','rtrrt','eeryrrt','tertert','1/28/2020')

select * from tbluserfeedback
/**Insurance table**/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[tblInsurance](
       [insurance_insId] [bigint] IDENTITY(1,1) NOT NULL,
	   [insurance_memberId] [bigint] NOT NULL,
	   [insurance_amount] [bigint] NOT NULL,
      
CONSTRAINT [PK_tbl_insurance] PRIMARY KEY CLUSTERED 
(
       [insurance_insId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO


insert into tblInsurance values(10005,500000)

/** User FeedBack Table **/

select *from [tblInsurance]
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[tbluserfeedback](
       [userfd_id] [bigint] IDENTITY(1,1) NOT NULL,
	   [userfd_ratingque1] [varchar](200) NOT NULL,
	   [userfd_ratingque2] [varchar](200) NOT NULL,
	   [userfd_ratingque3] [varchar](200) NOT NULL,
	   [userfd_ratingque4] [varchar](200) NOT NULL,
	   [userfd_ratingque5] [varchar](200) NOT NULL,
	   [userfd_ratingque6] [varchar](200) NOT NULL,
	   [userfd_ratingque7] [varchar](200) NOT NULL,
	   [userfd_ratingque8] [varchar](200) NOT NULL,
	   [userfd_ratingque9] [varchar](200) NOT NULL,
	   [userfd_ratingque10] [varchar](200) NOT NULL,
	   [userfd_assessmentdate] [date] NOT NULL
CONSTRAINT [PK_tbl_userfeedback] PRIMARY KEY CLUSTERED 
(
       [userfd_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[tblmember]  WITH CHECK ADD  CONSTRAINT [member_plan_code] FOREIGN KEY([member_plancode])
REFERENCES [dbo].[tblplancode] ([plan_code])
GO
ALTER TABLE [dbo].[tblmember] CHECK CONSTRAINT [member_plan_code]
GO

ALTER TABLE [dbo].[tblclaim]  WITH CHECK ADD  CONSTRAINT [claim_member_id] FOREIGN KEY([claim_memberid])
REFERENCES [dbo].[tblmember] ([member_id])
GO
ALTER TABLE [dbo].[tblclaim] CHECK CONSTRAINT [claim_member_id]
GO

ALTER TABLE [dbo].[tbluserfeedback]  WITH CHECK ADD  CONSTRAINT [userfd_assessment_id] FOREIGN KEY([userfd_assessmentid])
REFERENCES [dbo].[tblfeedback] ([feedback_assessmentid])
GO
ALTER TABLE [dbo].[tbluserfeedback] CHECK CONSTRAINT [userfd_assessment_id]
GO

ALTER TABLE [dbo].[tblInsurance]  WITH CHECK ADD  CONSTRAINT [insurance_insId] FOREIGN KEY([insurance_insId])
REFERENCES [dbo].[tblmember] ([member_id])
GO
ALTER TABLE [dbo].[tblInsurance] CHECK CONSTRAINT [insurance_insId]
GO

ALTER TABLE [dbo].[tblmember] ADD  [member_rejectedstatuis] bit

ALTER TABLE [dbo].[tbladmin] ADD  [admin_rejectedstatuis] bit


ALTER TABLE [dbo].[tblclaim] ALTER COLUMN [claim_status] varchar(10)

--ALTER TABLE [dbo].[tblmember] ALTER COLUMN [member_status] bit

ALTER TABLE [dbo].[tblmember] ADD  [member_status] bit

drop table tblmember
drop table tblInsurance
drop table tblplancode
drop table tbladmin
drop table tblclaim
drop table tblfeedback
drop table tbluserfeedback


select * from tbladmin
select * from tblmember
select * from tblclaim
select * from tblplan
select * from tbluserfeedback
select * from tblInsurance
select * from tblsuperlogin


ALTER TABLE [dbo].[tbladmin] ADD admin_status bit 
Alter table [dbo].[tblmember] ADD member_rej_message varchar(200) NULL
Alter table [dbo].[tblmember] ADD member_rej_claim_message varchar(200) NULL
Alter table [dbo].[tblclaim] ADD member_proofname1 varchar(50) NULL
Alter table [dbo].[tblclaim] ADD member_proofname2 varchar(50) NULL
Alter table [dbo].[tblclaim] ADD member_proofId1 varchar(100) NULL
Alter table [dbo].[tblclaim] ADD member_proofId2 varchar(100) NULL
Alter table [dbo].[tblclaim] ADD member_bills varchar(100) NULL

ALTER table [dbo].[tblclaim] ADD claim_rejectionmsg varchar(100) NULL

Alter table [dbo].[tbladmin] ADD admin_rej_message varchar(200) NULL


Alter table [dbo].[tblmember] ADD insurance_amount bigint NULL 

UPDATE [dbo].[tblmember] set member_status = 0 where member_id = 10017;

SET IDENTITY_INSERT [dbo].[tblclaim] ON
/* dotnet ef dbcontext scaffold "server=PCIN480252;database=ClaimsManagement;trusted_connection=yes" Microsoft.EntityFrameworkCore.SqlServer -o Models -f  */

select * from tblclaim
delete from [dbo].[tblclaim] where claim_id =10025


select * from tblclaim
select * from tbladmin